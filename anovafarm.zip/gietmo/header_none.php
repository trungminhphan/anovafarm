<?php
function __autoload($class_name) {
    require_once('../cls/class.' . strtolower($class_name) . '.php');
}
$session = new SessionManager();
$users = new Users();
require_once('../inc/functions.inc.php');
require_once('../inc/config.inc.php');
if(!$users->isLoggedIn()){ transfers_to('../login.html'); }
$id_user = $users->get_userid();
$id_congty = $users->get_id_congty();
?>